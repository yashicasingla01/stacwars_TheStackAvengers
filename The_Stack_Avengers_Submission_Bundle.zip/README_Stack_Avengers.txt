THE STACK AVENGERS — FINAL SUBMISSION FILES
============================================

1) The_Stack_Avengers_Final.pptx
   Revised 23-slide presentation. Text boxes are set to fit their shapes, and
   shapes are kept inside the slide canvas to reduce text/table boundary issues.

2) stack_avengers_analysis.py
   Complete Python source for:
   - PS2: Voyage-123 solar data cleaning, visualizations, daily summaries,
     correlations, and a Random Forest baseline with RMSE/R².
   - PS3: transit-depth screening, estimated planet radius, simplified orbit
     calculation, and CSV/JSON outputs.
   - PS4: transparent asteroid-water mission delivered-cost scenario calculator.

IMPORTANT SCIENTIFIC NOTE
The PS2 source report says the actual Voyage-123 CSV was not attached, so PS2
results cannot honestly be reported as measured until the real dataset is added.
The PS3 automatic transit routine is a screening helper; verify candidate dips
and do not treat it as definitive planet confirmation. PS4 cost inputs are
planning assumptions, not measured economics.

SETUP
  python -m pip install -r requirements_stack_avengers.txt

PS2 EXAMPLE
  python stack_avengers_analysis.py solar --csv voyage123_solar_data.csv --outdir outputs/solar

If your actual CSV has different headers, use:
  --timestamp "Timestamp" --radiation "Solar Radiation" --temperature "Temperature" --humidity "Humidity" --wind "Wind Speed" --sunrise "Sunrise"

PS3 EXAMPLE
CSV columns: system,time,brightness
  python stack_avengers_analysis.py exoplanet --csv light_curve.csv --outdir outputs/exoplanet

Optional stellar parameters for radius/orbit calculations:
  --star-radius-solar 0.8 --stellar-mass-solar 0.8
Set --normal-brightness when the assignment supplies a reliable out-of-transit
baseline. The default quantile baseline is only a rough screening heuristic.

PS4 EXAMPLE
  python stack_avengers_analysis.py mining --prospecting-cost 1000000 --transport-cost 5000000 --processing-cost 2000000 --delivery-cost 500000 --operations-cost 750000 --recovered-kg 1000 --delivery-fraction 0.9 --outdir outputs/mining

Replace example PS4 costs and recovered mass with your own assumptions. All
outputs are written to the selected output directory.
